console.log("I got a rainbow!");
console.log("and an extension called Bracket Pair Colorizer");